// src/constants/clientAvatars.js
export const CLIENT_AVATARS = {
  // ключом удобнее делать account_id (если есть), иначе account_name
  "Ahad Nazim": "https://video.karal.az/avatars/ahadnazim.jpg",
  "Tural Multi": "https://video.karal.az/avatars/gf-diamonds.png",
  "Elnur Agayev": "https://video.karal.az/avatars/gf.jpg",
  "Aliyev Fuad": "https://video.karal.az/avatars/Kapriz.png"
};
