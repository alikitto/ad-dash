import bgBody from "assets/img/background-body-admin.png";

export const bgAdmin = {
  styles: {
    global: (props) => ({
      body: {
        bgImage: bgBody,
        bgSize: "cover",
        bgPosition: "center center",
      },
    }),
  },
};
